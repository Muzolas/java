/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.dll;

import java.util.Scanner;

/**
 *
 * @author Muzaffer
 */
public class DLL {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        LinkedList dll = new LinkedList();
        int process;
        do {
            System.out.print("\n-------------------\n\tMenu\n-------------------\n1-Add\n2-Delete\n3-Search\n4-Print\n5-Exit\n-------------------\n\nSelect the process: ");
            process = sc.nextInt();

            switch (process) {

                case 1 -> {
                    dll.Add();
                }
                case 2 -> {
                    dll.Delete();
                }
                case 3 -> {
                    dll.Search();
                }
                case 4 -> {
                    dll.Print();
                }
                case 5 -> {
                    break;
                }
                default ->
                    System.out.println("Incorrect operation...");
            }
        } while (process != 5);

    }
}
