/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.dll;

import java.util.Scanner;

/**
 *
 * @author Muzaffer
 */
public class LinkedList {

    Scanner sc = new Scanner(System.in);
    private Node head = null;

    public void Add() {
        int process;
        do {
            System.out.print("\n-------------------\nAdd Menu\n-------------------\n1-Add to front\n2-Add to end\n3-Add before a node\n4-Add after a node\n5-Print\n6-Exit\n-------------------\n\nSelect the process: ");
            process = sc.nextInt();

            switch (process) {

                case 1 -> {

                    System.out.print("Enter the number you want to add: ");

                    int value = sc.nextInt();

                    Node newNode = new Node(value);

                    newNode.next = head;
                    newNode.previous = null;

                    if (head != null) {
                        head.previous = newNode;
                    }

                    head = newNode;

                }
                case 2 -> {

                    System.out.print("Enter the number you want to add: ");

                    int value = sc.nextInt();

                    Node newNode = new Node(value);

                    Node end = head;

                    newNode.next = null;

                    if (head == null) {
                        newNode.previous = null;
                        head = newNode;
                        return;
                    }
                    do {
                        end = end.next;

                    } while (end.next != null);

                    end.next = newNode;
                    newNode.previous = end;
                }
                case 3 -> {

                    System.out.print("Enter the number you want to add: ");
                    int value = sc.nextInt();
                    System.out.print("Before which node do you want to insert the number: : ");
                    int valueSought = sc.nextInt();
                    Node nextNode = Find(valueSought);

                    if (nextNode == null) {
                        System.out.println("The next node cannot be NULL...");

                    }

                    Node newNode = new Node(value);

                    newNode.previous = nextNode.previous;

                    nextNode.previous = newNode;

                    newNode.next = nextNode;

                    if (newNode.previous != null) {
                        newNode.previous.next = newNode;

                    } else {
                        head = newNode;
                    }

                }
                case 4 -> {

                    System.out.print("Enter the number you want to add: ");
                    int value = sc.nextInt();
                    System.out.print("After which node do you want to insert the number: ");
                    int valueSought = sc.nextInt();
                    Node previousNode = Find(valueSought);

                    if (previousNode == null) {
                        System.out.println("The previous node cannot be NULL...");
                    }

                    Node newNode = new Node(value);

                    newNode.next = previousNode.next;

                    previousNode.next = newNode;

                    newNode.previous = previousNode;

                    if (newNode.next != null) {
                        newNode.next.previous = newNode;

                    }
                }
                case 5 -> {
                    Print();
                }
                case 6 -> {
                    break;
                }
                default ->
                    System.out.println("Incorrect operation...");
            }
        } while (process != 6);

    }

    public void Delete() {

        System.out.print("Enter the number you want to delete: ");

        int value = sc.nextInt();

    }

    public void Search() {
        System.out.print("Enter the number you want to search for: ");

        int value = sc.nextInt();

    }

    public void Print() {

        Node availableNode = head;

        if (head == null) {
            System.out.println("List is empty...");
        } else {
            do {
                System.out.print(" " + availableNode.data);
                availableNode = availableNode.next;

            } while (availableNode != null);

        }

    }

    public Node Find(int valueSought) {
        Node end = head;

        while (end.next != null) {
            if (end.data == valueSought) {
                return end;
            }

            end = end.next;
        }

        if (end.data == valueSought) {
            return end;
        }

        return null;
    }
}
