/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import dosya.dosyaIslemleri;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import model.Poliklinik;

/**
 *
 * @author Muzaffer
 */
public class PoliklinikDAO {

    dosyaIslemleri dosya = new dosyaIslemleri();
    private final List<Poliklinik> poliklinikList = new ArrayList<>();

    public void addPoliklinik(Poliklinik p) throws IOException {

        dosya.addPoliklinik(p.toString(), "Poliklinik.txt");
    }

    public void delete(String Id) throws IOException {
        dosya.delete("Poliklinik.txt", Id);
    }

    public List<Poliklinik> getList() throws IOException {
        FileReader fR = new FileReader("C:\\Users\\Muzaffer\\Desktop\\Yeni klasör\\HastaneOtomasyon\\src\\dosya\\Poliklinik.txt");
        BufferedReader bR = new BufferedReader(fR);

        String line = bR.readLine();
        while (line != null) {
            String[] parts = line.split(",");

            Poliklinik p = new Poliklinik(Integer.parseInt(parts[0]), parts[1]);
            poliklinikList.add(p);

            line = bR.readLine();

        }

        return this.poliklinikList;
    }

    public void deleteUser(String Id) throws IOException {
        dosya.delete("Poliklinik.txt", Id);
    }
}
