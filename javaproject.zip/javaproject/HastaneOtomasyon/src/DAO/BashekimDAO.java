/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import dosya.*;
import helper.Helper;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

import model.Bashekim;
import model.Calisan;
import model.Doktor;
import model.Poliklinik;

/**
 *
 * @author Muzaffer
 */
public class BashekimDAO {

    dosyaIslemleri dosya = new dosyaIslemleri();
    private final List<Bashekim> bashekimList = new ArrayList<>();
    private final List<Calisan> calisanList = new ArrayList<>();
    private final List<Calisan> calisanListId = new ArrayList<>();

    public void addWorker(Doktor d, Poliklinik p) throws IOException {

        dosya.addWorker(d.getId(), d.getName(), p.getId(), p.getName(), "Calisan.txt");
    }

    public void addUser(Bashekim d) throws IOException {

        dosya.add(d, "User.txt");
    }

    public Bashekim returnBashekim(Bashekim newBashekim) throws IOException {
        List<Bashekim> list = this.getList();

        for (Bashekim k : list) {
            if (k.equals(newBashekim)) {

                Bashekim h = new Bashekim(k.getId(), k.getTcNo(), k.getSifre(), k.getName(), k.getType());

                return h;
            }
        }
        return null;

    }

    public List<Bashekim> getList() throws IOException {
        FileReader fR = new FileReader("C:\\Users\\Muzaffer\\Desktop\\Yeni klasör\\HastaneOtomasyon\\src\\dosya\\User.txt");
        try ( BufferedReader bR = new BufferedReader(fR)) {
            String line = bR.readLine();
            while (line != null) {
                String[] parts = line.split(",");
                if ("Bashekim".equals(parts[4])) {
                    Bashekim b = new Bashekim(Integer.parseInt(parts[0]), parts[1], parts[2], parts[3], parts[4]);
                    bashekimList.add(b);
                }
                line = bR.readLine();
            }
        }
        return this.bashekimList;
    }

    public List<Calisan> getListCalisan() throws IOException {
        FileReader fR = new FileReader("C:\\Users\\Muzaffer\\Desktop\\Yeni klasör\\HastaneOtomasyon\\src\\dosya\\Calisan.txt");
        try ( BufferedReader bR = new BufferedReader(fR)) {
            String line = bR.readLine();
            while (line != null) {
                String[] parts = line.split(",");

                Calisan c = new Calisan(Integer.parseInt(parts[0]), parts[2], parts[4]);
                calisanList.add(c);

                line = bR.readLine();
            }
        }
        return this.calisanList;
    }

    public boolean checkUser(Bashekim newbashekim) throws IOException {
        List<Bashekim> list = this.getList();
        boolean check = false;

        for (Bashekim b : list) {
            if (b.equals(newbashekim)) {
                Helper.ShowMsg("success");
                check = true;
            }
        }
        return check;
    }

    public List<Calisan> getListCalisanId(int Id) throws IOException {
        FileReader fR = new FileReader("C:\\Users\\Muzaffer\\Desktop\\Yeni klasör\\HastaneOtomasyon\\src\\dosya\\Calisan.txt");

        try ( BufferedReader bR = new BufferedReader(fR)) {
            String line = bR.readLine();
            while (line != null) {
                String[] parts = line.split(",");

                if (String.valueOf(Id).equals(parts[3])) {

                    Calisan calisan = new Calisan(Integer.parseInt(parts[1]), parts[2]);
                    calisanListId.add(calisan);
                }

                line = bR.readLine();
            }
        }
        return this.calisanListId;
    }

}
