/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package helper;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author Muzaffer
 */
public class ID_sayac {

    public static int idSayac(String str) throws IOException {

        int ctrl = 0;

        FileReader fileReader = new FileReader("C:\\Users\\Muzaffer\\Desktop\\Yeni klasör\\HastaneOtomasyon\\src\\dosya\\" + str);
        BufferedReader bufferedReader = new BufferedReader(fileReader);

        String line = bufferedReader.readLine();

        while (line != null) {

            ctrl += 1;
            line = bufferedReader.readLine();

        }

        return ctrl;

    }

}
