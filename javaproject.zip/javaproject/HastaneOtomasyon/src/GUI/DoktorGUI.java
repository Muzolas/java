/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

import DAO.DoktorDAO;
//import com.toedter.calendar.JDateChooser;
import java.awt.Font;
import java.io.IOException;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import model.Doktor;
import model.DoktorCalismaSaati;

import yonetim.action.DoktorGUI_action;

/**
 *
 * @author Muzaffer
 */
public final class DoktorGUI extends JFrame {

    private Doktor d;
    private DoktorCalismaSaati dcs;
    private JComboBox cbox_time;
    //private JDateChooser date_calismaSaatleri;
    private JPanel pnl_pencere, pnl_calismaSaatleri;
    private JTabbedPane w_tabpane;
    private JScrollPane w_scrollpane;
    private JTable table_calismaSaatleri;
    private JButton btn_dateEkle, btn_cikis, btn_dateSil;
    private JLabel lbl_msj;
    private JTextField txtfld_kullaniciId;
    private final DefaultTableModel whourModel;
    public Object[] whourData;

    public JTextField getTxtfld_kullaniciId() {
        if (txtfld_kullaniciId == null) {
            this.txtfld_kullaniciId = new JTextField();
            txtfld_kullaniciId.setBounds(615, 10, 160, 30);
        }
        return txtfld_kullaniciId;
    }

    public void setTxtfld_kullaniciId(JTextField txtfld_kullaniciId) {
        this.txtfld_kullaniciId = txtfld_kullaniciId;
    }

    public DoktorCalismaSaati getDcs() {
        if (dcs == null) {
            this.dcs = new DoktorCalismaSaati();
        }
        return dcs;
    }

    public void setDcs(DoktorCalismaSaati dcs) {
        this.dcs = dcs;
    }

    public Doktor getD() {

        return d;
    }

    public void setD(Doktor d) {
        this.d = d;
    }

    public DoktorGUI(Doktor d) throws IOException {

        this.d = d;

        DoktorDAO doktorDAO = new DoktorDAO(d);

        whourModel = new DefaultTableModel();
        Object[] colWhourName = new Object[3];

        colWhourName[0] = "ID";
        colWhourName[1] = "Ad Soyad";
        colWhourName[2] = "Çalışma Saatleri";

        whourModel.setColumnIdentifiers(colWhourName);
        whourData = new Object[3];

        List<DoktorCalismaSaati> whourList = doktorDAO.getListWhour();

        for (int i = 0; i < whourList.size(); i++) {

            whourData[0] = whourList.get(i).getId();
            whourData[1] = whourList.get(i).getD().getName();
            whourData[2] = whourList.get(i).getWdate();

            this.whourModel.addRow(whourData);

        }

        build();
    }

    public void updateWhourModel() throws IOException {

        DefaultTableModel clearModel = whourModel;
        clearModel.setRowCount(0);
        DoktorDAO doktorDAO = new DoktorDAO(d);

        List<DoktorCalismaSaati> whourList = doktorDAO.getListWhour();
        for (int i = 0; i < whourList.size(); i++) {
            whourData[0] = whourList.get(i).getId();
            whourData[1] = whourList.get(i).getD().getName();
            whourData[2] = whourList.get(i).getWdate();

            this.whourModel.addRow(whourData);
        }

    }

    public void build() throws IOException {
        add(getPnl_pencere());
        setBounds(300, 300, 1000, 600);
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public JPanel getPnl_pencere() throws IOException {
        if (pnl_pencere == null) {
            this.pnl_pencere = new JPanel();
            pnl_pencere.setLayout(null);

            pnl_pencere.add(getLbl_msj());
            pnl_pencere.add(getBtn_cikis());
            pnl_pencere.add(getW_tabpane());
        }
        return pnl_pencere;
    }

    public void setPnl_pencere(JPanel pnl_pencere) {
        this.pnl_pencere = pnl_pencere;
    }

    public JPanel getPnl_calismaSaatleri() throws IOException {
        if (pnl_calismaSaatleri == null) {
            this.pnl_calismaSaatleri = new JPanel();
            pnl_calismaSaatleri.setLayout(null);

            pnl_calismaSaatleri.add(getW_scrollpane());
            //pnl_calismaSaatleri.add(getDate_calismaSaatleri());
            pnl_calismaSaatleri.add(getCbox_time());

            pnl_calismaSaatleri.add(getBtn_dateEkle());
            pnl_calismaSaatleri.add(getBtn_dateSil());
            //pnl_calismaSaatleri.add(getDate_calismaSaatleri());
            pnl_calismaSaatleri.add(getTxtfld_kullaniciId());

        }
        return pnl_calismaSaatleri;
    }

    public void setPnl_calismaSaatleri(JPanel pnl_calismaSaatleri) {
        this.pnl_calismaSaatleri = pnl_calismaSaatleri;
    }

    public JComboBox getCbox_time() {
        if (cbox_time == null) {
            this.cbox_time = new JComboBox();
            cbox_time.setBounds(275, 10, 150, 30);

            cbox_time.addItem("06:00-07:00");
            cbox_time.addItem("07:00-08:00");
            cbox_time.addItem("08:00-09:00");
            cbox_time.addItem("09:00-10:00");
            cbox_time.addItem("10:00-11:00");
            cbox_time.addItem("11:00-12:00");
            cbox_time.addItem("12:00-13:00");
            cbox_time.addItem("13:00-14:00");
            cbox_time.addItem("14:00-15:00");
            cbox_time.addItem("15:00-16:00");
            cbox_time.addItem("16:00-17:00");
            cbox_time.addItem("17:00-18:00");

        }
        return cbox_time;
    }

    public void setCbox_time(JComboBox cbox_time) {
        this.cbox_time = cbox_time;
    }

//    public JDateChooser getDate_calismaSaatleri() {
//        if (date_calismaSaatleri == null) {
//            this.date_calismaSaatleri = new JDateChooser();
//            date_calismaSaatleri.setBounds(10, 10, 250, 30);
//        }
//        return date_calismaSaatleri;
//    }
//
//    public void setDate_calismaSaatleri(JDateChooser date_calismaSaatleri) {
//        this.date_calismaSaatleri = date_calismaSaatleri;
//    }

    public JTabbedPane getW_tabpane() throws IOException {
        if (w_tabpane == null) {
            this.w_tabpane = new JTabbedPane();
            w_tabpane.setBounds(10, 100, 960, 450);
            w_tabpane.add("Çalışma Saatleri", getPnl_calismaSaatleri());
        }
        return w_tabpane;
    }

    public void setW_tabpane(JTabbedPane w_tabpane) {
        this.w_tabpane = w_tabpane;
    }

    public JScrollPane getW_scrollpane() {
        if (w_scrollpane == null) {
            this.w_scrollpane = new JScrollPane();
            w_scrollpane.setViewportView(getTable_calismaSaatleri());
            w_scrollpane.setBounds(10, 45, 940, 375);
        }
        return w_scrollpane;
    }

    public void setW_scrollpane(JScrollPane w_scrollpane) {
        this.w_scrollpane = w_scrollpane;
    }

    public JTable getTable_calismaSaatleri() {
        if (table_calismaSaatleri == null) {
            this.table_calismaSaatleri = new JTable();
            table_calismaSaatleri.setModel(whourModel);

        }
        return table_calismaSaatleri;
    }

    public void setTable_calismaSaatleri(JTable table_calismaSaatleri) {
        this.table_calismaSaatleri = table_calismaSaatleri;
    }

    public JButton getBtn_dateEkle() {
        if (btn_dateEkle == null) {
            this.btn_dateEkle = new JButton("Ekle");
            btn_dateEkle.setBounds(440, 10, 160, 30);

            this.btn_dateEkle.addActionListener(new DoktorGUI_action(this));
        }
        return btn_dateEkle;
    }

    public void setBtn_dateEkle(JButton btn_dateEkle) {
        this.btn_dateEkle = btn_dateEkle;
    }

    public JButton getBtn_cikis() {
        if (btn_cikis == null) {
            this.btn_cikis = new JButton("Çıkış");
            btn_cikis.setBounds(800, 30, 150, 40);
            btn_cikis.setFont(new Font("YU Gothic UI Semibold", Font.PLAIN, 20));
            this.btn_cikis.addActionListener(new DoktorGUI_action(this));
        }
        return btn_cikis;
    }

    public void setBtn_cikis(JButton btn_cikis) {
        this.btn_cikis = btn_cikis;
    }

    public JButton getBtn_dateSil() {
        if (btn_dateSil == null) {
            this.btn_dateSil = new JButton("Sil");
            btn_dateSil.setBounds(790, 10, 160, 30);
            this.btn_dateSil.addActionListener(new DoktorGUI_action(this));
        }
        return btn_dateSil;
    }

    public void setBtn_dateSil(JButton btn_dateSil) {
        this.btn_dateSil = btn_dateSil;
    }

    public JLabel getLbl_msj() {
        if (lbl_msj == null) {
            this.lbl_msj = new JLabel("Hoşgeldiniz Sayın " + d.getName());
            lbl_msj.setBounds(20, 30, 700, 40);
            lbl_msj.setFont(new Font("YU Gothic UI Semibold", Font.PLAIN, 30));
        }
        return lbl_msj;
    }

    public void setLbl_msj(JLabel lbl_msj) {
        this.lbl_msj = lbl_msj;
    }

}
