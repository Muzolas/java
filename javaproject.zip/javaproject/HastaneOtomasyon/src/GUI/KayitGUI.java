/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

import javax.swing.*;
import yonetim.action.KayitGUI_action;

/**
 *
 * @author Muzaffer
 */
public final class KayitGUI extends JFrame {

    private JPanel pnl_pencere;
    private JLabel lbl_adSoyad, lbl_tcNo, lbl_sifre;
    private JTextField txtfld_adSoyad, txtfld_tcNo;
    private JPasswordField pwfld_sifre;
    private JButton btn_kayıtOl, btn_geriDon;

    public KayitGUI() {
        build();
    }

    public void build() {
        add(getPnl_pencere());
        setSize(300, 350);
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public JPanel getPnl_pencere() {
        if (pnl_pencere == null) {
            this.pnl_pencere = new JPanel();
            pnl_pencere.setLayout(null);

            pnl_pencere.add(getLbl_adSoyad());
            pnl_pencere.add(getLbl_tcNo());
            pnl_pencere.add(getLbl_sifre());
            pnl_pencere.add(getTxtfld_adSoyad());
            pnl_pencere.add(getTxtfld_tcNo());
            pnl_pencere.add(getPwfld_sifre());
            pnl_pencere.add(getBtn_kayıtOl());
            pnl_pencere.add(getBtn_geriDon());

        }
        return pnl_pencere;
    }

    public void setPnl_pencere(JPanel pnl_pencere) {
        this.pnl_pencere = pnl_pencere;
    }

    public JLabel getLbl_adSoyad() {
        if (lbl_adSoyad == null) {
            this.lbl_adSoyad = new JLabel("Ad Soyad");
            lbl_adSoyad.setBounds(10, 5, 250, 30);
        }
        return lbl_adSoyad;
    }

    public void setLbl_adSoyad(JLabel lbl_adSoyad) {
        this.lbl_adSoyad = lbl_adSoyad;
    }

    public JLabel getLbl_tcNo() {
        if (lbl_tcNo == null) {
            this.lbl_tcNo = new JLabel("T.C. Numarası");
            lbl_tcNo.setBounds(10, 75, 250, 30);
        }
        return lbl_tcNo;
    }

    public void setLbl_tcNo(JLabel lbl_tcNo) {
        this.lbl_tcNo = lbl_tcNo;
    }

    public JLabel getLbl_sifre() {
        if (lbl_sifre == null) {
            this.lbl_sifre = new JLabel("Şifre");
            lbl_sifre.setBounds(10, 140, 260, 30);
        }
        return lbl_sifre;
    }

    public void setLbl_sifre(JLabel lbl_sifre) {
        this.lbl_sifre = lbl_sifre;
    }

    public JTextField getTxtfld_adSoyad() {
        if (txtfld_adSoyad == null) {
            this.txtfld_adSoyad = new JTextField();
            txtfld_adSoyad.setBounds(10, 40, 260, 30);
        }
        return txtfld_adSoyad;
    }

    public void setTxtfld_adSoyad(JTextField txtfld_adSoyad) {
        this.txtfld_adSoyad = txtfld_adSoyad;
    }

    public JTextField getTxtfld_tcNo() {
        if (txtfld_tcNo == null) {
            this.txtfld_tcNo = new JTextField();
            txtfld_tcNo.setBounds(10, 105, 260, 30);
        }
        return txtfld_tcNo;
    }

    public void setTxtfld_tcNo(JTextField txtfld_tcNo) {
        this.txtfld_tcNo = txtfld_tcNo;
    }

    public JPasswordField getPwfld_sifre() {
        if (pwfld_sifre == null) {
            this.pwfld_sifre = new JPasswordField();
            pwfld_sifre.setBounds(10, 170, 260, 30);
        }
        return pwfld_sifre;
    }

    public void setPwfld_sifre(JPasswordField pwfld_sifre) {
        this.pwfld_sifre = pwfld_sifre;
    }

    public JButton getBtn_kayıtOl() {
        if (btn_kayıtOl == null) {
            this.btn_kayıtOl = new JButton("Kayıt Ol");
            btn_kayıtOl.setBounds(10, 220, 260, 30);
            this.btn_kayıtOl.addActionListener(new KayitGUI_action(this));
        }
        return btn_kayıtOl;
    }

    public void setBtn_kayıtOl(JButton btn_kayıtOl) {
        this.btn_kayıtOl = btn_kayıtOl;
    }

    public JButton getBtn_geriDon() {
        if (btn_geriDon == null) {
            this.btn_geriDon = new JButton("Geri Dön");
            btn_geriDon.setBounds(10, 260, 260, 30);
            this.btn_geriDon.addActionListener(new KayitGUI_action(this));
        }
        return btn_geriDon;
    }

    public void setBtn_geriDon(JButton btn_geriDon) {
        this.btn_geriDon = btn_geriDon;
    }

}
