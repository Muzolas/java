/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

import java.awt.Font;
import java.awt.Image;
import javax.swing.*;
import yonetim.action.*;

/**
 *
 * @author Muzaffer
 */
public class GirisGUI extends JFrame {

    private Image logo;
    private JPanel pnl_hasta, pnl_doktor, pnl_basHekim, pnl_pencere;
    private JButton btn_kayit, btn_hastaGiris, btn_doktorGiris, btn_basHekimGiris;
    private JLabel lbl_logo, lbl_title, lbl_hastaTC, lbl_hastaSifre, lbl_doktorTC, lbl_doktorSifre, lbl_basHekimTC, lbl_basHekimSifre;
    private JTextField txtfld_hastaTC, txtfld_doktorTC, txtfld_basHekimTC;
    private JTabbedPane w_tabpane;
    private JPasswordField pwfld_hastaSifre, pwfld_doktorSifre, pwfld_basHekimSifre;

    public GirisGUI() {
        build();
    }

    public void build() {
        add(getPnl_pencere());
        setBounds(700, 300, 500, 400);

        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public JPanel getPnl_pencere() {
        if (pnl_pencere == null) {
            this.pnl_pencere = new JPanel();
            pnl_pencere.setLayout(null);
            pnl_pencere.add(getLbl_logo());
            pnl_pencere.add(getLbl_title());
            pnl_pencere.add(getW_tabpane());

        }

        return pnl_pencere;
    }

    public void setPnl_pencere(JPanel pnl_pencere) {
        this.pnl_pencere = pnl_pencere;
    }

    public JPanel getPnl_hasta() {
        if (pnl_hasta == null) {
            this.pnl_hasta = new JPanel();

            pnl_hasta.setLayout(null);
            pnl_hasta.add(getLbl_hastaTC());
            pnl_hasta.add(getLbl_hastaSifre());
            pnl_hasta.add(getTxtfld_hastaTC());
            pnl_hasta.add(getPwfld_hastaSifre());
            pnl_hasta.add(getBtn_kayit());
            pnl_hasta.add(getBtn_hastaGiris());

        }
        return pnl_hasta;
    }

    public void setPnl_hasta(JPanel pnl_hasta) {
        this.pnl_hasta = pnl_hasta;
    }

    public JPanel getPnl_doktor() {
        if (pnl_doktor == null) {
            this.pnl_doktor = new JPanel();

            pnl_doktor.setLayout(null);

            pnl_doktor.add(getLbl_doktorTC());
            pnl_doktor.add(getLbl_doktorSifre());
            pnl_doktor.add(getTxtfld_doktorTC());
            pnl_doktor.add(getPwfld_doktorSifre());
            pnl_doktor.add(getBtn_doktorGiris());
        }
        return pnl_doktor;
    }

    public void setPnl_doktor(JPanel pnl_doktor) {
        this.pnl_doktor = pnl_doktor;
    }

    public JPanel getPnl_basHekim() {
        if (pnl_basHekim == null) {
            this.pnl_basHekim = new JPanel();

            pnl_basHekim.setLayout(null);

            pnl_basHekim.add(getLbl_basHekimTC());
            pnl_basHekim.add(getLbl_basHekimSifre());
            pnl_basHekim.add(getTxtfld_basHekimTC());
            pnl_basHekim.add(getPwfld_basHekimSifre());
            pnl_basHekim.add(getBtn_basHekimGiris());
        }
        return pnl_basHekim;

    }

    public void setPnl_basHekim(JPanel pnl_basHekim) {
        this.pnl_basHekim = pnl_basHekim;
    }

    public JButton getBtn_basHekimGiris() {
        if (btn_basHekimGiris == null) {
            this.btn_basHekimGiris = new JButton("Giriş");

            btn_basHekimGiris.setBounds(80, 150, 280, 30);
            btn_basHekimGiris.setFont(new Font("YU Gothic UI Semibold", Font.PLAIN, 15));
            this.btn_basHekimGiris.addActionListener(new GirisGUI_action(this));
        }
        return btn_basHekimGiris;

    }

    public void setBtn_basHekimGiris(JButton btn_basHekimGiris) {
        this.btn_basHekimGiris = btn_basHekimGiris;
    }

    public JLabel getLbl_basHekimTC() {
        if (lbl_basHekimTC == null) {

            this.lbl_basHekimTC = new JLabel();
            this.lbl_basHekimTC = new JLabel("T.C. Numaranız:");
            lbl_basHekimTC.setBounds(80, 50, 110, 50);
            lbl_basHekimTC.setFont(new Font("YU Gothic UI Semibold", Font.PLAIN, 15));
        }
        return lbl_basHekimTC;

    }

    public void setLbl_basHekimTC(JLabel lbl_basHekimTC) {
        this.lbl_basHekimTC = lbl_basHekimTC;
    }

    public JLabel getLbl_basHekimSifre() {
        if (lbl_basHekimSifre == null) {

            this.lbl_basHekimSifre = new JLabel();
            lbl_basHekimSifre = new JLabel("Şifreniz: ");
            lbl_basHekimSifre.setBounds(80, 90, 100, 50);
            lbl_basHekimSifre.setFont(new Font("YU Gothic UI Semibold", Font.PLAIN, 15));
        }
        return lbl_basHekimSifre;

    }

    public void setLbl_basHekimSifre(JLabel lbl_basHekimSifre) {
        this.lbl_basHekimSifre = lbl_basHekimSifre;
    }

    public JTextField getTxtfld_basHekimTC() {
        if (txtfld_basHekimTC == null) {

            this.txtfld_basHekimTC = new JTextField();
            txtfld_basHekimTC.setBounds(210, 60, 150, 30);
        }
        return txtfld_basHekimTC;

    }

    public void stTextfld_basHekimTC(JTextField txtfld_basHekimTC) {

        this.txtfld_basHekimTC = txtfld_basHekimTC;
    }

    public JPasswordField getPwfld_basHekimSifre() {
        if (pwfld_basHekimSifre == null) {

            this.pwfld_basHekimSifre = new JPasswordField();
            pwfld_basHekimSifre.setBounds(210, 100, 150, 30);
        }
        return pwfld_basHekimSifre;

    }

    public void setPwfld_basHekimSifre(JPasswordField pwfld_basHekimSifre) {
        this.pwfld_basHekimSifre = pwfld_basHekimSifre;
    }

    public JButton getBtn_kayit() {
        if (btn_kayit == null) {
            this.btn_kayit = new JButton("Kayıt Ol");
            btn_kayit.setBounds(80, 150, 130, 30);
            btn_kayit.setFont(new Font("YU Gothic UI Semibold", Font.PLAIN, 15));
            this.btn_kayit.addActionListener(new GirisGUI_action(this));
        }
        return btn_kayit;
    }

    public void setBtn_kayit(JButton btn_kayit) {
        this.btn_kayit = btn_kayit;
    }

    public JButton getBtn_hastaGiris() {
        if (btn_hastaGiris == null) {
            this.btn_hastaGiris = new JButton("Giriş");
            btn_hastaGiris.setBounds(220, 150, 130, 30);
            btn_hastaGiris.setFont(new Font("YU Gothic UI Semibold", Font.PLAIN, 15));
            this.btn_hastaGiris.addActionListener(new GirisGUI_action(this));

        }
        return btn_hastaGiris;
    }

    public void setBtn_hastaGiris(JButton btn_hastaGiris) {
        this.btn_hastaGiris = btn_hastaGiris;
    }

    public JButton getBtn_doktorGiris() {
        if (btn_doktorGiris == null) {
            this.btn_doktorGiris = new JButton("Giriş");

            btn_doktorGiris.setBounds(80, 150, 280, 30);
            btn_doktorGiris.setFont(new Font("YU Gothic UI Semibold", Font.PLAIN, 15));
            this.btn_doktorGiris.addActionListener(new GirisGUI_action(this));
        }
        return btn_doktorGiris;
    }

    public void setBtn_doktorGiris(JButton btn_doktorGiris) {
        this.btn_doktorGiris = btn_doktorGiris;
    }

    public Image getLogo() {
        if (logo == null) {
            // this.logo = new ImageIcon(this.getClass().getResource("/cardiogram.png")).getImage();
        }
        return logo;
    }

    public void setLogo(Image logo) {
        this.logo = logo;
    }

    public JLabel getLbl_logo() {
        if (lbl_logo == null) {
            this.lbl_logo = new JLabel();

            lbl_logo.setBounds(100, 10, 50, 50);
            //lbl_logo.setIcon(new ImageIcon(this.getClass().getResource("/cardiogram.png")));
        }
        return lbl_logo;
    }

    public void setLbl_logo(JLabel lbl_logo) {
        this.lbl_logo = lbl_logo;
    }

    public JLabel getLbl_title() {
        if (lbl_title == null) {
            this.lbl_title = new JLabel("Hastane Otomasyon Sistemine Hoşgeldiniz");
            lbl_title.setBounds(50, 40, 500, 50);
            lbl_title.setFont(new Font("YU Gothic UI Semibold", Font.PLAIN, 20));
        }
        return lbl_title;
    }

    public void setLbl_title(JLabel lbl_title) {
        this.lbl_title = lbl_title;
    }

    public JLabel getLbl_hastaTC() {
        if (lbl_hastaTC == null) {
            this.lbl_hastaTC = new JLabel("T.C. Numaranız:");
            lbl_hastaTC.setBounds(80, 50, 110, 50);
            lbl_hastaTC.setFont(new Font("YU Gothic UI Semibold", Font.PLAIN, 15));

        }
        return lbl_hastaTC;
    }

    public void setLbl_hastaTC(JLabel lbl_hastaTC) {
        this.lbl_hastaTC = lbl_hastaTC;
    }

    public JLabel getLbl_hastaSifre() {
        if (lbl_hastaSifre == null) {

            this.lbl_hastaSifre = new JLabel();
            lbl_hastaSifre = new JLabel("Şifreniz: ");
            lbl_hastaSifre.setBounds(80, 90, 100, 50);
            lbl_hastaSifre.setFont(new Font("YU Gothic UI Semibold", Font.PLAIN, 15));
        }
        return lbl_hastaSifre;
    }

    public void setLbl_hastaSifre(JLabel lbl_hastaSifre) {
        this.lbl_hastaSifre = lbl_hastaSifre;
    }

    public JLabel getLbl_doktorTC() {
        if (lbl_doktorTC == null) {

            this.lbl_doktorTC = new JLabel();
            this.lbl_doktorTC = new JLabel("T.C. Numaranız:");
            lbl_doktorTC.setBounds(80, 50, 110, 50);
            lbl_doktorTC.setFont(new Font("YU Gothic UI Semibold", Font.PLAIN, 15));
        }
        return lbl_doktorTC;
    }

    public void setLbl_doktorTC(JLabel lbl_doktorTC) {
        this.lbl_doktorTC = lbl_doktorTC;
    }

    public JLabel getLbl_doktorSifre() {
        if (lbl_doktorSifre == null) {

            this.lbl_doktorSifre = new JLabel();
            lbl_doktorSifre = new JLabel("Şifreniz: ");
            lbl_doktorSifre.setBounds(80, 90, 100, 50);
            lbl_doktorSifre.setFont(new Font("YU Gothic UI Semibold", Font.PLAIN, 15));
        }
        return lbl_doktorSifre;
    }

    public void setLbl_doktorSifre(JLabel lbl_doktorSifre) {
        this.lbl_doktorSifre = lbl_doktorSifre;
    }

    public JTextField getTxtfld_hastaTC() {
        if (txtfld_hastaTC == null) {

            this.txtfld_hastaTC = new JTextField();
            txtfld_hastaTC.setBounds(210, 60, 150, 30);
        }
        return txtfld_hastaTC;
    }

    public void setTxtfld_hastaTC(JTextField txtfld_hastaTC) {
        this.txtfld_hastaTC = txtfld_hastaTC;
    }

    public JTextField getTxtfld_doktorTC() {
        if (txtfld_doktorTC == null) {

            this.txtfld_doktorTC = new JTextField();
            txtfld_doktorTC.setBounds(210, 60, 150, 30);
        }
        return txtfld_doktorTC;
    }

    public void setTxtfld_doktorTC(JTextField txtfld_doktorTC) {
        this.txtfld_doktorTC = txtfld_doktorTC;
    }

    public JPasswordField getPwfld_hastaSifre() {
        if (pwfld_hastaSifre == null) {

            this.pwfld_hastaSifre = new JPasswordField();
            pwfld_hastaSifre.setBounds(210, 100, 150, 30);
        }

        return pwfld_hastaSifre;
    }

    public void setPwfld_hastaSifre(JPasswordField pwfld_hastaSifre) {
        this.pwfld_hastaSifre = pwfld_hastaSifre;
    }

    public JPasswordField getPwfld_doktorSifre() {
        if (pwfld_doktorSifre == null) {

            this.pwfld_doktorSifre = new JPasswordField();
            pwfld_doktorSifre.setBounds(210, 100, 150, 30);
        }
        return pwfld_doktorSifre;
    }

    public void setPwfld_doktorSifre(JPasswordField pwfld_doktorSifre) {
        this.pwfld_doktorSifre = pwfld_doktorSifre;
    }

    public JTabbedPane getW_tabpane() {
        if (w_tabpane == null) {

            this.w_tabpane = new JTabbedPane();
            w_tabpane.add("Hasta Giriş", getPnl_hasta());
            w_tabpane.add("Doktor Giriş", getPnl_doktor());
            w_tabpane.add("Başhekim Giriş", getPnl_basHekim());
            w_tabpane.setBounds(0, 100, 500, 400);

        }
        return w_tabpane;
    }

    public void setW_tabpane(JTabbedPane w_tabpane) {
        this.w_tabpane = w_tabpane;
    }

}
