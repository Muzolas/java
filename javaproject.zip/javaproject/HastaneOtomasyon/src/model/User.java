/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Objects;

/**
 *
 * @author Muzaffer
 */
public class User {

    private int Id;
    private String tcNo;
    private String name;
    private String sifre;
    private String type;

    public User(int Id) {
        this.Id = Id;
    }

    public User(String name) {
        this.name = name;
    }

    public User() {

    }

    public User(String tcNo, String sifre) {
        this.tcNo = tcNo;
        this.sifre = sifre;
    }

    public int getId() {

        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public User(int Id, String tcNo, String sifre, String name, String type) {
        this.Id = Id;
        this.tcNo = tcNo;
        this.name = name;
        this.sifre = sifre;
        this.type = type;
    }

    public User(String tcNo, String sifre, String name) {
        this.tcNo = tcNo;
        this.sifre = sifre;
        this.name = name;
    }

    public String getTcNo() {
        return tcNo;
    }

    public void setTcNo(String tcNo) {
        this.tcNo = tcNo;
    }

    public String getName() {

        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSifre() {
        return sifre;
    }

    public void setSifre(String sifre) {
        this.sifre = sifre;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 17 * hash + Objects.hashCode(this.tcNo);
        hash = 17 * hash + Objects.hashCode(this.sifre);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final User other = (User) obj;
        if (!Objects.equals(this.tcNo, other.tcNo)) {
            return false;
        }
        return Objects.equals(this.sifre, other.sifre);
    }

    @Override
    public String toString() {
        return "User{" + "Id=" + Id + ", tcNo=" + tcNo + ", name=" + name + ", sifre=" + sifre + ", type=" + type + '}';
    }

}
