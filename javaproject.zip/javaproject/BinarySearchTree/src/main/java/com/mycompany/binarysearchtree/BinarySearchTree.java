/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.binarysearchtree;

import java.util.Scanner;

/**
 * @author Muzaffer Beysan Kalem No: 02210224031 Lesson: Data Structures
 * Homework: Binary Search Tree
 *
 */
public class BinarySearchTree {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        //İkili Arama Ağacı oluşturuyoruz.
        BST tree = new BST();

        int process;
        do {
            System.out.print("""
                               
                             
                               -------------------
                               \tMenu
                               -------------------
                               1-Add
                               2-Delete
                               3-Find
                               4-Find Minumum
                               5-Find Maximum    
                               6-Height of Tree
                               7-Number of Nodes  
                               8-Sort by InOrder
                               9-Sort by PreOrder
                               10-Sort by PostOrder
                               11-Exit
                               -------------------
                               
                             
                               Select the process:  """);

            process = sc.nextInt();

            switch (process) {
                case 1 -> {
                    tree.Add();
                }
                case 2 -> {
                    tree.Delete();
                }
                case 3 -> {
                    tree.Find();
                }
                case 4 -> {
                    tree.FindMin();
                }
                case 5 -> {
                    tree.FindMax();
                }
                case 6 -> {
                     tree.HeightOfTree();
                }
                case 7 -> {
                    tree.NumberOfNodes();
                }
                case 8 -> {
                    tree.SortInOrder();
                }
                case 9 -> {
                   tree.SortPreOrder();;
                }
                case 10 -> {
                    tree.SortPostOrder();
                }
                case 11 -> {
                    break;
                }
                default ->
                    System.out.println("Incorrect operation...");
            }
        } while (process != 11);

    }
}
