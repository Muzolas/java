/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.binarysearchtree;

/**
 * @author Muzaffer Beysan Kalem
 * No: 02210224031
 * Lesson: Data Structures
 * Homework: Binary Search Tree
 *
 */
public class Node {

    //Düğüme veri, sağ ve sol ollmak üzere 3 özellik tanımlıyoruz.
    int data;
    Node left, right;

    public Node(int value) {
        //Düğüme gelen değeri düğümün verisine aktarıyoruz.
        this.data = value;
        //Düğümün solunu ve sağını null atıyorz.
        left = right = null;
    }
}
