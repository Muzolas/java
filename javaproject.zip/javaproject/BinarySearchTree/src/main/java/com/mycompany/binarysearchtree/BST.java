/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.binarysearchtree;

import java.util.Scanner;

/**
 * @author Muzaffer Beysan Kalem No: 02210224031 Lesson: Data Structures
 * Homework: Binary Search Tree
 *
 */
public class BST {

    Scanner sc = new Scanner(System.in);

    //İkili Arama Ağacının kökü oluşturuluyor.
    Node root;

    //İkili Arama Ağacının kökü null değerine eşitliyoruz.
    BST() {
        root = null;
    }

    //İkili Arama Ağacının düğüm ekleme fonksiyonu.
    public Node AddNode(Node root, int value) {

        //İkili Arama Ağacında hiç düğüm yoksa ilk gelen eleman kök oluyor.
        if (root == null) {
            root = new Node(value);
            return root;
        } //İkili Arama Ağacında düğüm varsa kökten büyük veya eşitse kökün soluna ekleniyor.
        else if (root.data >= value) {
            root.left = AddNode(root.left, value);
        } //İkili Arama Ağacında düğüm varsa kökten küçükse kökün sağına ekleniyor.
        else {
            root.right = AddNode(root.right, value);
        }
        //İkili Arama Ağacında kökü kullanmak için sürekli dönderiyoruz.
        return root;
    }

    //İkili Arama Ağacının düğüm silme fonksiyonu.
    public Node DeleteNode(Node root, int value) {

        //İkili Arama Ağacında sayı olmadığı için değeri düğüme aktarıyoruz.
        Node newNode = new Node(value);

        //İkili Arama Ağacında silmek istediğimiz düğüm varsa.
        if (search(root, value) == true) {

            //İkili Arama Ağacında kök boşsa silecek eleman olmadığından null dönderiyoruz.
            if (root == null) {
                return null;
            } //İkili Arama Ağacında silmek istediğimiz düğüm kökten küçükse sola doğru silinecek düğümü bulmaya çalışıyoruz.
            else if (newNode.data < root.data) {
                root.left = DeleteNode(root.left, value);
            } //İkili Arama Ağacında silmek istediğimiz düğüm kökten büyükse sağa doğru silinecek düğümü bulmaya çalışıyoruz.
            else if (newNode.data > root.data) {
                root.right = DeleteNode(root.right, value);
            }//İkili Arama Ağacında silmek istediğimiz düğümü bulunca silme işlemine başlıyoruz.
            else if (root.data == newNode.data) {

                //İkili Arama Ağacında silmek istediğimiz düğümün sağı ve solu doluysa.
                if (root.left != null && root.right != null) {
                    int max = FindMaxData(root.left);
                    root.data = max;
                    root.left = DeleteNode(root.left, max);
                    System.out.print("\nNumber " + value + " deleted...");
                    return root;
                } //İkili Arama Ağacında silmek istediğimiz düğümün solu doluysa kendisini silip yerine soldaki geliyor.
                else if (root.left != null) {
                    System.out.print("\nNumber " + value + " deleted...");
                    return root.left;
                } //İkili Arama Ağacında silmek istediğimiz düğümün sağı doluysa kendisini silip yerine sağdaki geliyor.
                else if (root.right != null) {
                    System.out.print("\nNumber " + value + " deleted...");
                    return root.right;
                } //İkili Arama Ağacında silmek istediğimiz düğümün sağı ve solu boşsa kendisi direkt siliniyor.

                System.out.print("\nNumber " + value + " deleted...");
                return null;

            }
        }//İkili Arama Ağacında silmek istediğimiz düğüm yoksa.
        else {
            System.out.print("\nThe node you want to delete wasn't found in the binary search tree...");
        }
        //İkili Arama Ağacında rootu bir daha kullanmak için sürekli dönderiyoruz.
        return root;
    }

    //İkili Arama Ağacının düğüm arama fonksiyonu.
    public boolean search(Node root, int value) {
        //İkili Arama Ağacında hiç kök yoksa düğüm de olmayacağından aranacak eleman olmaz bu yüzden false dönderiyoruz.
        if (root == null) {
            return false;
        }//İkili Arama Ağacında aradığımız düğümü bulunca true dönderiyoruz.
        else if (root.data == value) {
            return true;
        } //İkili Arama Ağacında aradığımız düğüm eğer kökten küçükse sola doğru aramaya devam ediyoruz.
        else if (root.data > value) {
            return search(root.left, value);
        }//İkili Arama Ağacında aradığımız düğüm eğer kökten büyükse sağa doğru aramaya devam ediyoruz. 
        else {
            return search(root.right, value);
        }
    }

    //İkili Arama Ağacının en küçük düğümünü bulan fonksiyon.
    public int FindMinData(Node root) {

        //İkili Arama Ağacının en küçük düğümü bulmak için solu boş olana kadar devam ediyoruz.
        if (root.left != null) {
            return FindMinData(root.left);
        }//İkili Arama Ağacında en soldaki düğüme geldiğimizde en küçük düğümü elde ediyoruz.
        else {
            return root.data;
        }
    }

    //İkili Arama Ağacının en büyük düğümünü bulan fonksiyon.
    public int FindMaxData(Node root) {

        //İkili Arama Ağacının en büyük düğümü bulmak için sağı boş olana kadar devam ediyoruz.
        if (root.right != null) {
            return FindMaxData(root.right);
        }//İkili Arama Ağacında en soldaki düğüme geldiğimizde en büyük düğümü elde ediyoruz.
        else {
            return root.data;
        }
    }

    //İkili Arama Ağacının yüksekliğini bulan fonksiyon.
    public int Height(Node root) {
        if (root == null) {
            return 0;
        } else {
            int left = 0, right = 0;

            left = Height(root.left);
            right = Height(root.right);

            if (left > right) {
                return left + 1;
            } else {
                return right + 1;
            }
        }
    }

    //İkili Arama Ağacında kaç düğüm olduğunu bulan fonksiyon.
    public int Nodes(Node root) {
        if (root == null) {
            return 0;
        } else {
            return Nodes(root.left) + 1 + Nodes(root.right);
        }
    }

    //İkili Arama Ağacının inOrder bir şekilde sıralama fonksiyonu.
    public void inOrder(Node root) {

        //İkili Arama Ağacında hiç düğüm yoksa ikili arama ağacı boştur.
        if (root == null) {
            return;
        }//İkili Arama Ağacında inOrder sıralama için sırayla SOL-KÖK-SAĞ şeklinde yazdırılır. 
        else {
            inOrder(root.left);
            System.out.print(root.data + " ");
            inOrder(root.right);
        }
    }

    //İkili Arama Ağacının preOrder bir şekilde sıralama fonksiyonu.
    public void preOrder(Node root) {
        if (root == null) {
            return;
        }//İkili Arama Ağacında inOrder sıralama için sırayla KÖK-SOL-SAĞ şeklinde yazdırılır. 
        else {
            System.out.print(root.data + " ");
            preOrder(root.left);
            preOrder(root.right);
        }
    }

    //İkili Arama Ağacının postOrder bir şekilde sıralama fonksiyonu.
    public void postOrder(Node root) {
        if (root == null) {
            return;
        }//İkili Arama Ağacında inOrder sıralama için sırayla SOL-SAĞ-KÖK şeklinde yazdırılır.
        else {
            postOrder(root.left);
            postOrder(root.right);
            System.out.print(root.data + " ");
        }
    }

    //İkili Arama Ağacının kullanıcıdan alınan değeri, düğüm ekleme fonksiyonuna gönderen fonksiyon.
    public void Add() {
        System.out.print("\nEnter the number you want to add: ");
        int value = sc.nextInt();
        this.root = AddNode(root, value);
    }

    //İkili Arama Ağacının kullanıcıdan alınan değeri, düğüm silme fonksiyonuna gönderen fonksiyon.
    public void Delete() {
        if (root == null) {
            System.out.print("\nBinary Search Tree is empty...");
        } else {
            System.out.print("\nEnter the number you want to delete: ");
            int value = sc.nextInt();
            this.root = DeleteNode(root, value);
        }
    }

    //İkili Arama Ağacının kullanıcıdan alınan değeri, düğüm arama fonksiyonuna gönderen fonksiyon.
    public void Find() {

        if (root == null) {
            System.out.print("\nBinary Search Tree is empty...");
        } else {
            System.out.print("\nEnter the number you want to find: ");
            int value = sc.nextInt();
            if (search(this.root, value) == true) {
                System.out.print("\n" + value + " is found...");
            } else {
                System.out.print("\n" + value + " is not found...");
            }
        }
    }

    //İkili Arama Ağacında bulunan en küçük düğümü bulan fonksiyonuna gönderen fonksiyon.
    public void FindMin() {
        if (root == null) {
            System.out.print("\nBinary Search Tree is empty...");
        } else {
            System.out.print("\nSmallest node in binary search tree: " + FindMinData(this.root));
        }
    }

    //İkili Arama Ağacında bulunan en büyük düğümü bulan fonksiyonuna gönderen fonksiyon.
    public void FindMax() {
        if (root == null) {
            System.out.print("\nBinary Search Tree is empty...");
        } else {
            System.out.print("\nBiggest node in binary search tree: " + FindMaxData(this.root));
        }
    }

    public void HeightOfTree() {
        if (root == null) {
            System.out.print("\nBinary Search Tree is empty...");
        } else {
            System.out.print("\nHeight of Tree: " + Height(this.root));
        }
    }

    public void NumberOfNodes() {
        if (root == null) {
            System.out.print("\nBinary Search Tree is empty...");
        } else {
            System.out.print("\nNumber of nodes in the tree: " + Nodes(this.root));
        }
    }

    //İkili Arama Ağacının inOrder bir şekilde sıralama fonksiyona gönderen fonksiyon.
    public void SortInOrder() {

        if (root == null) {
            System.out.print("\nBinary Search Tree is empty...");
        } else {
            System.out.print("\nSorted InOrder: ");
            inOrder(root);
        }
    }

    //İkili Arama Ağacının preOrder bir şekilde sıralama fonksiyona gönderen fonksiyon.
    public void SortPreOrder() {

        if (root == null) {
            System.out.print("\nBinary Search Tree is empty...");
        } else {
            System.out.print("\nSorted PreOrder: ");
            preOrder(root);
        }
    }

    //İkili Arama Ağacının postOrder bir şekilde sıralama fonksiyona gönderen fonksiyon.
    public void SortPostOrder() {

        if (root == null) {
            System.out.print("\nBinary Search Tree is empty...");
        } else {
            System.out.print("\nSorted PostOrder: ");
            postOrder(root);
        }
    }
}
