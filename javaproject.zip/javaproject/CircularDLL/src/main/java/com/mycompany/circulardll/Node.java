/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.circulardll;

/**
 *
 * @author Muzaffer
 */
public class Node {
    int data;
    Node next;
    Node previous;

    public Node(int value) {
        this.data = value;
    }

    public Node() {
    }

    
    
}
