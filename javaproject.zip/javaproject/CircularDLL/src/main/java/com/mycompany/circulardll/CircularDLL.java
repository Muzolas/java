/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.circulardll;

import java.util.Scanner;

/**
 *
 * @author Muzaffer
 */
public class CircularDLL {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        LinkedList cdll = new LinkedList();
        int process;
        do {
            System.out.print("""
                             
                             ---------------------
                             \tMenu
                             ---------------------
                             1-Add Menu
                             2-Delete Menu
                             3-Search
                             4-Print
                             5-Exit
                             ---------------------
                             
                             Select the process:  """);
            process = sc.nextInt();

            switch (process) {

                case 1 -> {
                    cdll.Add();
                }
                case 2 -> {
                    cdll.Delete();
                }
                case 3 -> {
                    cdll.Search();
                }
                case 4 -> {
                    cdll.Print();
                }
                case 5 -> {
                    break;
                }
                default ->
                    System.out.println("Incorrect operation...");
            }
        } while (process != 5);
    }
}
