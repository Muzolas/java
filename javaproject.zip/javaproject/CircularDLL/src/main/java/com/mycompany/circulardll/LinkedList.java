/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.circulardll;

import java.util.Scanner;

/**
 *
 * @author Muzaffer
 */
public class LinkedList {

    Scanner sc = new Scanner(System.in);

    private Node head = null;

    public void Add() {
        Print();
        int process;
        do {
            System.out.print("""
                             
                             ---------------------
                             Add Menu
                             ---------------------
                             1-Add to front
                             2-Add to end
                             3-Add before a node
                             4-Add after a node
                             5-Exit
                             ---------------------
                             
                             Select the process: """);
            
            process = sc.nextInt();

            switch (process) {

                case 1 -> {

                    System.out.print("Enter the number you want to add: ");

                    int value = sc.nextInt();

                    Node newNode = new Node(value);
                    
                    if (head == null) {
                        head = newNode;
                        head.next = head;
                        head.previous = head;
                    }

                    
                    head.previous.next = newNode;
                    newNode.next = head;
                    newNode.previous = head.previous;
                    head.previous = newNode;

                    head = newNode;

                    Print();

                }
                case 2 -> {

                    System.out.print("Enter the number you want to add: ");

                    int value = sc.nextInt();

                    Node newNode = new Node(value);

                    newNode.next = null;

                    if (head == null) {
                        head = newNode;
                        newNode.previous = head;
                        newNode.next = head;

                    }

                    Node temp = head;
                    do {

                        temp = temp.next;

                    } while (temp.next != head);

                    temp.next = newNode;
                    newNode.previous = temp;
                    newNode.next = head;
                    head.previous = newNode;

                    Print();

                }
                case 3 -> {

                    System.out.print("Enter the number you want to add: ");
                    int value = sc.nextInt();
                    System.out.print("Before which node do you want to insert the number: ");
                    int valueSought = sc.nextInt();

                    Node nextNode = Find(valueSought);

                    Node newNode = new Node(value);

                    newNode.previous = nextNode.previous;

                    nextNode.previous = newNode;

                    newNode.next = nextNode;
                    
                    
                    
                    if (newNode.previous != head) {
                        newNode.previous.next = newNode;

                    } else {
                        head = newNode;
                    }

                    Print();

                }
                case 4 -> {

                    System.out.print("Enter the number you want to add: ");
                    int value = sc.nextInt();
                    System.out.print("After which node do you want to insert the number: ");
                    int valueSought = sc.nextInt();

                    Node previousNode = Find(valueSought);

                    Node newNode = new Node(value);

                    newNode.next = previousNode.next;

                    previousNode.next = newNode;

                    newNode.previous = previousNode;

                    if (newNode.next != head) {
                        newNode.next.previous = newNode;

                    }
                    Print();
                }
                case 5 -> {
                    break;
                }
                default ->
                    System.out.println("Incorrect operation...");
            }
        } while (process != 5);

    }

    public void Delete() {
        Print();
        int process;
        do {
            System.out.print("""
                             
                             ---------------------
                             Delete Menu
                             ---------------------
                             1-Delete to front
                             2-Delete to end
                             3-Delete before a node
                             4-Delete after a node
                             5-Exit
                             ---------------------
                             
                             Select the process: """);
            process = sc.nextInt();

            switch (process) {

                case 1 -> {

                    if (head == null) {
                        System.out.println("List is empty...");
                    } else if (head.next == head) {
                        head = null;
                    } else {
                        head.previous.next = head.next;
                        head.next.previous = head.previous;
                        head = head.next;
                    }

                    Print();

                }
                case 2 -> {

                    Node temp = head.previous;
                    if (head == null) {
                        System.out.println("List is empty...");
                    } else if (head.next == head) {
                        head = null;
                    } else {
                        temp.previous.next = temp.next;
                        temp.next.previous = temp.previous;
                    }
                    Print();

                }
                case 3 -> {
                    System.out.print("Before which node do you want to delete the number: ");
                    int valueSought = sc.nextInt();

                    if (head == null) {
                        System.out.println("List is empty...");
                    } else if (head.next == head) {
                        head = null;
                    } else {
                        Node temp = head;
                        do {
                            if (temp.next.data == valueSought) {
                                if (temp == head) {
                                    head.previous.next = head.next;
                                    head.next.previous = head.previous;
                                    head = head.next;
                                }
                                temp.previous.next = temp.next;
                                temp.next.previous = temp.previous;
                            }
                            temp = temp.next;
                        } while (temp != head);

                    }
                    Print();

                }
                case 4 -> {

                    System.out.print("After which node do you want to delete the number: ");
                    int valueSought = sc.nextInt();

                    if (head == null) {
                        System.out.println("List is empty...");
                    } else if (head.next == head) {
                        head = null;
                    } else {
                        Node temp = head;
                        do {
                            if (temp.data == valueSought) {
                                if (temp.next == head) {
                                    head.previous.next = head.next;
                                    head.next.previous = head.previous;
                                    head = head.next;
                                }
                                temp.next.next.previous = temp;
                                temp.next = temp.next.next;
                            }
                            temp = temp.next;
                        } while (temp != head);

                    }
                    Print();

                }

                case 5 -> {
                    break;
                }
                default ->
                    System.out.println("Incorrect operation...");
            }
        } while (process != 5);

    }

    public int Search() {
        
        System.out.print("Enter the number to search: ");
        int value = sc.nextInt();

        
        Node temp = head;

        
        int count = 0, flag = 0;

        
        if (temp == null) {
            return -1;
        } else {
            while (temp.next != head) {  
                
                count++;
                
                if (temp.data == value) {
                    flag = 1;
                    count--;
                    break;
                }

                temp = temp.next;
            }

            if (temp.data == value) {
                count++;
                flag = 1;
            }

            if (flag == 1) {
                System.out.println(value + " found at location " + count);
            } else {
                System.out.println(value + " not found..");
            }
        }
        return -1;
    }

    public void Print() {
        Node temp = head;

        if (head == null) {
            System.out.println("List is empty...");

        } else {
            do {
                System.out.print(" " + temp.data);
                temp = temp.next;

            } while (temp != head);

        }
    }

    public Node Find(int valueSought) {

        Node temp = head;

        while (temp.next != head) {
            if (temp.data == valueSought) {
                return temp;
            }

            temp = temp.next;
        }

        if (temp.data == valueSought) {
            return temp;
        }

        return null;
    }

}