/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.linkedliststackmain;

/**
 *
 * @author Muzaffer
 */

//Bağlı liste ile yığıt yapısı
public class Linkedliststack {

    // Bağlı liste düğümü
    private class Node {

        int data;
        Node next;
    }
    // Global bir top değişkeni oluşturmak
    Node first;

    // Kurucu metod
    Linkedliststack() {
        this.first = null;
    }

    // Yığıt yapısına değer ekleme metodu
    public void Push(int value) {

        // Yeni bir düğüm oluşturma ve bellekten yer ayırma
        Node temp = new Node();

        temp.data = value;

        temp.next = first;

        first = temp;
    }

    // Yığının boş olup olmadığını kontrol etme
    public boolean isEmpty() {
        return first == null;
    }

    // Yığıt yapısından değer silme metodu
    public void Pop() {
        if (first == null) {
            System.out.println("\nStack underflow.");
            return;
        }
        first = first.next;
    }

    // Yığıt yapısında aranan sayıyı bulma metodu
    public int search(int number) {
        int index = 0;
        if (first == null) {
            System.out.println("\nStack underflow.");
        } else {
            Node temp = first;
            while (temp != null) {
                if (temp.data == number) {
                    return index;
                }
                index++;
                temp = temp.next;
            }
        }
        return -1;
    }

    // Yığıtın içindeki değerleri yazdıran method
    public void display() {
        if (first == null) {
            System.out.println("\nStack underflow.");

        } else {
            Node temp = first;
            while (temp != null) {
                System.out.printf("%d ", temp.data);
                temp = temp.next;
            }
        }
    }
}
