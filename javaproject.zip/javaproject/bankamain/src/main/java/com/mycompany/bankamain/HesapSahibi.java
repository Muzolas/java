/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bankamain;

/**
 *
 * @author Muzaffer
 */
public abstract class HesapSahibi {

    private String isim;
    private String soyİsim;
    private int TC;
    private int phoneNumber;

    public HesapSahibi(String isim, String soyİsim, int TC, int phoneNumber) {
        this.isim = isim;
        this.soyİsim = soyİsim;
        this.TC = TC;
        this.phoneNumber = phoneNumber;
    }

    public String getIsim() {
        return isim;
    }

    public void setIsim(String isim) {
        this.isim = isim;
    }

    public String getSoyİsim() {
        return soyİsim;
    }

    public void setSoyİsim(String soyİsim) {
        this.soyİsim = soyİsim;
    }

    public int getTC() {
        return TC;
    }

    public void setTC(int TC) {
        this.TC = TC;
    }

    public int getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
