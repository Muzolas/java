/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bankamain;

import java.util.Scanner;

/**
 *
 * @author Muzaffer
 */

public class Hesap extends HesapSahibi {

    Scanner sc = new Scanner(System.in);

    protected int bakiye;

    public Hesap(String isim, String soyİsim, int TC, int phoneNumber) {
        super(isim, soyİsim, TC, phoneNumber);
        this.bakiye = 1000;
    }

    public void ParaYatır() {

        int miktar;

        System.out.println("Bakiyeniz: " + this.bakiye);
        System.out.print("Yatırılacak para miktrını giriniz: ");
        miktar = sc.nextInt();
        this.bakiye += miktar;
        System.out.println("Yeni bakiyeniz: " + this.bakiye);

    }

    public void ParaCek() {

        int miktar;

        System.out.println("Bakiyeniz: " + this.bakiye);
        System.out.print("Cekilicek para miktrını giriniz: ");
        miktar = sc.nextInt();
        if (miktar > this.bakiye) {
            System.out.println("Bakiyeniz: " + this.bakiye);
            System.out.println("Hesapta Yeterli miktarda para yok...");
        } else {
            this.bakiye -= miktar;
            System.out.println("Yeni bakiyeniz: " + this.bakiye);

        }
    }

    public void BilgileriGoster() {
        System.out.println("\nİsim: " + this.getIsim() + "\nSoyisim: " + this.getSoyİsim() + "\nTC: " + this.getTC() +  "\nPhone Number: " + this.getPhoneNumber() + "\nBakiye: " + this.bakiye);
    }

}
