/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.bankamain;

import java.util.Scanner;

/**
 *
 * @author Muzaffer
 */
public class Bankamain {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Hesap h = new Hesap("yung", "muzo", 1, 2);
        int işlem;
        do {
            System.out.print("\n-------------------\n\tMenü\n-------------------\n1-Para Yatır\n2-Para Çek\n3-Bilgileri Göster\n4-Exit\n-------------------\n\nİşlem Seçiniz: ");
            işlem = sc.nextInt();

            switch (işlem) {

                case 1:
                    h.ParaYatır();
                    break;

                case 2:
                    h.ParaCek();
                    break;
                case 3:
                    h.BilgileriGoster();
                    break;
                case 4:
                    break;
                default:
                    System.out.println("Incorrect operation...");
            }
        } while (işlem != 4);
    }

}
