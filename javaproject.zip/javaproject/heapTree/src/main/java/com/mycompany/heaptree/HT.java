/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.heaptree;

import java.util.Scanner;



/**
 *
 * @author Muzaffer
 */
public class HT {
    
    Scanner sc = new Scanner(System.in);
    
    Node root;
    
    HT(){
        root = null;
    }
    
    public Node AddNode(Node root,int value){
        
        if(root == null){
            root = new Node(value);
        
        }else{
            
        }
        
        return root;
    }
    
    public void Add(){
        System.out.print("\nEnter the number you want to add: ");
        int value = sc.nextInt();
        this.root = AddNode(root, value);
        
    }
    
    public void Sort() {

        if (root == null) {
            System.out.print("\nBinary Search Tree is empty...");
        } else {
            System.out.print("\nSorted InOrder: ");
            Order(root);
        }
    }
    
    
    public void Order(Node root) {

        
        if (root == null) {
        }
        else {
            Order(root.right);
            Order(root.left);
            System.out.print(root.data + " ");
            
        }
    }
    




   

   
    
}
