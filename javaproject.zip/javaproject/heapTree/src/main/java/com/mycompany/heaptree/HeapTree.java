/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.heaptree;

import java.util.Scanner;

/**
 *
 * @author Muzaffer
 */
public class HeapTree {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        HT heapTree = new HT();
        
        int process;
        
        do {
            
            System.out.print("""
                               
                             
                               -------------------
                               \tMenu
                               -------------------
                               1-Add
                               2-Delete
                               3-Search
                               4-Exit
                               -------------------
                               
                               Select the process:  """);

            process = sc.nextInt();

            switch (process) {
                case 1 -> {
                    heapTree.Add();
                }
                case 2 -> {
                    heapTree.Sort();
                    //heapTree.Delete();
                }
                case 3 -> {
                    //heapTree.Search();
                }
                case 4 -> {
                    break;
                }       
                default ->
                    System.out.println("Incorrect operation...");
            }
        } while (process != 4);
    }
}
