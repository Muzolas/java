/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cll;

import java.util.Scanner;

/**
 *
 * @author Muzaffer
 */
public class LinkedList {

    Scanner sc = new Scanner(System.in);
    private Node head = null;
    private Node tail = null;

    public void Add() {

        System.out.print("Enter the number you want to add: ");

        int value = sc.nextInt();

        Node newNode = new Node(value);

        if (head == null) {
            head = newNode;
        } else {
            tail.next = newNode;
        }
        tail = newNode;
        newNode.next = head;
        
        
    }

    public void Delete() {

        System.out.print("Enter the number you want to delete: ");

        int value = sc.nextInt();

        Node availableNode = head;

        if (head == null) {
            System.out.println("List is empty...");
        } else {
            do {

                Node nextNode = availableNode.next;

                if (nextNode.data == value) {

                    if (head == tail) {
                        head = null;
                        tail = null;
                    } else {
                        availableNode.next = nextNode.next;
                        if (head == nextNode) {
                            head = head.next;
                        }
                        if (tail == nextNode) {
                            tail = availableNode;
                        }
                    }
                }
                availableNode = nextNode;
            } while (availableNode != head);
        }
    }

    public void Search() {
        System.out.print("Enter the number you want to search for: ");

        int value = sc.nextInt();

        Node availableNode = head;

        if (head == null) {
            System.out.println("List is empty...");
        } else {
            do {

                if (availableNode.data == value) {
                    System.out.print("Number found: " + value);
                    break;
                }
                
                availableNode = availableNode.next;
                System.out.print("Number not found...");
            } while (availableNode != head);
            
        }

    }

    public void Print() {

        Node availableNode = head;

        if (head == null) {
            System.out.println("List is empty...");
        } else {
            do {
                System.out.print(" " + availableNode.data);
                availableNode = availableNode.next;

            } while (availableNode != head);

        }
    }
}
