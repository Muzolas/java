/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ders2;

/**
 *
 * @author Fatih
 */
public class MainPage {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        SkorTahtasi s = new SkorTahtasi(10);
        Oyuncu o = new Oyuncu("Fatih Okumuş", 100);
        
        s.ekle(o);
        
        
        Oyuncu o2 = new Oyuncu("Fatih Okumuş2", 50);
        s.ekle(o2);
        
        Oyuncu o3 = new Oyuncu("Fatih Okumuş3", 80);
        s.ekle(o3);
        
        
        //s.PrintToConsole();
        
        BLPage frm = new BLPage();
        frm.show();
        
        
        
        
    }
    
}
