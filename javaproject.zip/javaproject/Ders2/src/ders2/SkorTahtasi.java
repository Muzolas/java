/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ders2;

/**
 *
 * @author Fatih
 */
public class SkorTahtasi {
    public Oyuncu[] oyuncular;
    public int oyuncusayisi = 0;
    
    public SkorTahtasi(int kapasite){
        oyuncular = new Oyuncu[kapasite];
    }
    
    public void ekle(Oyuncu o)
    {
        oyuncular[oyuncusayisi] = o;
        oyuncusayisi++;
        
        for (int i = oyuncusayisi-1; i > 0; i--) {
            if(oyuncular[i].puan < oyuncular[i-1].puan)
            { 
                Oyuncu temp = oyuncular[i];
                oyuncular[i] = oyuncular[i-1];
                oyuncular[i-1]= temp;
            }
            
        }
    }
    
    public void PrintToConsole()
    {
        for (int i = oyuncusayisi-1; i >=0 ; i--) {
            System.out.println(oyuncular[i].AdSoyad + " - " + oyuncular[i].puan);
        }
    }
}
