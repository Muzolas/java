/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ders2;

/**
 *
 * @author Fatih
 */
public class BagliListe {
    
    public Dugum ilk;
    public Dugum son;
    public int size;
    
    public void OneEkle(Dugum a)
    {
        if(size == 0)
        {
            ilk = a;
            son = a;
        }
        else
        {
            a.sonraki = ilk;
            ilk = a;
        }
        size++;
    }
    public void ArkayaEkle(Dugum a)
    {
        if(size == 0)
        {
            ilk = a;
            son = a;
        }
        else
        {
            a.sonraki = null;
            son.sonraki = a;
        }
        size++;
    }
    
}
