/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daireselbagliliste;

/**
 *
 * @author Fatih
 */
public class DBagliListe {
    public Dugum ilk = null;
    public Dugum son = null;
    
    public void Ekle(int deger)
    {
        Dugum yeniDugum = new Dugum(deger);
        
        if(ilk == null)
        {
            ilk = yeniDugum;
        }
        else
        {
            son.sonraki = yeniDugum;
        }
        
        yeniDugum.sonraki = ilk;
        son = yeniDugum;
        
    }
    
    public boolean DugumBul(int arananDeger)
    {
        Dugum mevcutDugum = ilk;
        
        if(ilk == null)
            return false;
        else
        {
            do{
                
                if(mevcutDugum.deger == arananDeger)
                    return true;
                
                mevcutDugum = mevcutDugum.sonraki;
            }
            while(mevcutDugum != ilk);
            
            return false;
        }
    }
    
    public void Sil(int silinecekDeger)
    {
        Dugum mevcutDugum = ilk;
        
        if(ilk == null)
            return;
        else
        {
            do{
                Dugum sonrakiDugum = mevcutDugum.sonraki;
                if(sonrakiDugum.deger == silinecekDeger)
                {
                    if(ilk == son)
                    {
                        ilk = null;
                        son = null;
                    }
                    else
                    {
                        mevcutDugum.sonraki = sonrakiDugum.sonraki;
                        
                        if(ilk == sonrakiDugum)
                        {
                            ilk = ilk.sonraki;
                        }
                        if(son == sonrakiDugum)
                        {
                            son = mevcutDugum;
                        }
                    }
                }
                
                mevcutDugum = sonrakiDugum;
            }
            while(mevcutDugum != ilk);
            
            
        }
    }
    
}
