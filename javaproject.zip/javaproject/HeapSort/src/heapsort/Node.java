/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package heapsort;

/**
 *
 * @author Muzaffer
 */
public class Node {

    public Node left, right, parent;

    public int value, level, index;

    public Node(int val) {
        value = val;
    }
}
