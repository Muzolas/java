/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package avltree;

/**
 *
 * @author Muzaffer
 */
public class Node {

    public int value;
    public Node left;
    public Node right;
    public int level;

    public Node(int val) {
        value = val;
    }
}
