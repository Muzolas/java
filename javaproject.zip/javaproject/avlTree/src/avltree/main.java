/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package avltree;

/**
 *
 * @author Muzaffer
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        AvlTree tree = new AvlTree();
        tree.Insert(5);
        tree.Insert(10);
        tree.Insert(15);
        tree.Insert(11);
        tree.Insert(6);
        tree.Insert(4);
        tree.Insert(3);

        tree.inorder();
        tree.Delete(15);
        tree.inorder();
    }

}
