package entity;

import java.util.Objects;

public class User {
    private Long id;
    private String nameSurname;
    private String username;
    private String email;
    private String password;
    
    
    
    public User() {
    }

    public User(Long id, String username, String email, String password, String nameSurname) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.password = password;
        this.nameSurname = nameSurname;
    }

    public User(String username, String email, String password, String nameSurname) {
        this.username = username;
        this.email = email;
        this.password = password;
        this.nameSurname = nameSurname;
    }
    


    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 29 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final User other = (User) obj;
        return Objects.equals(this.id, other.id);
    }

    @Override
    public String toString() {
        return super.toString(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    
}
