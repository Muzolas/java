
package entity;

import java.util.Date;
import java.util.Objects;


public class Usage {
    
    private Long id;
    private Resident resident;
    private Block block;
    private Apartment apartment;
    private int no;
    private Date start;
    private Date ende;

    public Usage() {
    }

    public Usage(Long id, Resident resident, Block block, Apartment apartment, int no, Date start, Date ende) {
        this.id = id;
        this.resident = resident;
        this.block = block;
        this.apartment = apartment;
        this.no = no;
        this.start = start;
        this.ende = ende;
    }

    public Usage(Resident resident, Block block, Apartment apartment, int no, Date start, Date ende) {
        this.resident = resident;
        this.block = block;
        this.apartment = apartment;
        this.no = no;
        this.start = start;
        this.ende = ende;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Resident getResident() {
        if(resident == null)
            this.resident = new Resident();
        
        return resident;
    }

    public void setResident(Resident resident) {
        this.resident = resident;
    }

    public Block getBlock() {
        if(block == null)
            this.block = new Block();
        
        return block;
    }

    public void setBlock(Block block) {
        this.block = block;
    }

    public Apartment getApartment() {
        if(apartment == null)
            this.apartment = new Apartment();
        
        return apartment;
    }

    public void setApartment(Apartment apartment) {
        this.apartment = apartment;
    }

    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public Date getStart() {
        return start;
    }

    public void setStart(Date start) {
        this.start = start;
    }

    public Date getEnde() {
        return ende;
    }

    public void setEnde(Date ende) {
        this.ende = ende;
    }

    @Override
    public String toString() {
        return super.toString(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 47 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Usage other = (Usage) obj;
        return Objects.equals(this.id, other.id);
    }
    
    
    
}
