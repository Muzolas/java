
package entity;

import java.util.Objects;

public class Apartment {
    private Long id;
    private Block block;
    private ApartmentType type;
    
    private int count;

    public Apartment() {
    }

    public Apartment(Long id, Block bid, ApartmentType type, int count) {
        this.id = id;
        this.block = bid;
        this.type = type;
        this.count = count;
    }

    public Apartment(Block bid, ApartmentType type, int count) {
        this.block = bid;
        this.type = type;
        this.count = count;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Block getBlock() {
        if(getBlock() == null){
             this.block = new Block();
        }
           
        return block;
    }

    public void setBlock(Block block) {
        this.block = block;
    }

    public ApartmentType getType() {
        if(type == null){
            this.type = new ApartmentType();
        }
            
        return type;
    }

    public void setType(ApartmentType type) {
        this.type = type;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    @Override
    public String toString() {
        return super.toString(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Apartment other = (Apartment) obj;
        return Objects.equals(this.id, other.id);
    }
    
}
