
package entity;

import java.util.Objects;

public class Block {
    private Long id;
    private String block;

    public Block() {
    }

    public Block(Long id, String block) {
        this.id = id;
        this.block = block;
    }

    public Block(String block) {
        this.block = block;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 67 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Block other = (Block) obj;
        return Objects.equals(this.id, other.id);
    }

    @Override
    public String toString() {
        return id+";"+block;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBlock() {
        return block;
    }

    public void setBlock(String block) {
        this.block = block;
    }
    
    
}
