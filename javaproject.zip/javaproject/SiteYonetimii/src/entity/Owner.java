package entity;

import java.util.Objects;

public class Owner {
    private Long id;
    private Block block;
    private Apartment apartment;
    private User user;
    
    private int no;

    public Owner() {
    }

    public Owner(Long id, Block block, Apartment apartment, User user, int no) {
        this.id = id;
        this.block = block;
        this.apartment = apartment;
        this.user = user;
        this.no = no;
    }

    public Owner(Block block, Apartment apartment, User user, int no) {
        this.block = block;
        this.apartment = apartment;
        this.user = user;
        this.no = no;
    }

   
    @Override
    public String toString() {
        return super.toString(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 89 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Owner other = (Owner) obj;
        return Objects.equals(this.id, other.id);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Block getBlock() {
        if(block == null){
            this.block = new Block();
        }
            
        
        return block;
    }

    public void setBlock(Block block) {
        
        this.block = block;
    }

    public Apartment getApartment() {
        if(apartment == null){
            this.apartment = new Apartment();
        }
        return apartment;
    }

    public void setApartment(Apartment apartment) {
        this.apartment = apartment;
    }

    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }
     public User getUser() {
         if(user == null)
             this.user = new User();
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    
    
}
