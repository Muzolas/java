
package entity;

import java.util.Objects;

public class ApartmentType {
    private Long id;
    private String description;
    private int metreKare;

    public ApartmentType(Long id, String description, int metreKare) {
        this.id = id;
        this.description = description;
        this.metreKare = metreKare;
    }

    public ApartmentType() {
    }

    public ApartmentType(String description, int metreKare) {
        this.description = description;
        this.metreKare = metreKare;
    }

    @Override
    public String toString() {
        return super.toString(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 29 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ApartmentType other = (ApartmentType) obj;
        return Objects.equals(this.id, other.id);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getMetreKare() {
        return metreKare;
    }

    public void setMetreKare(int metreKare) {
        this.metreKare = metreKare;
    }
    
    
}
