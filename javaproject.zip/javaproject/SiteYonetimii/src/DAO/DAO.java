
package DAO;

import java.util.List;


public interface DAO<T> {
    public void insert(T entity);
    public List<T> getList();
    
}
