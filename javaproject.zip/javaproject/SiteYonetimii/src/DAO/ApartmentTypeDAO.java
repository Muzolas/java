/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import entity.ApartmentType;
import java.util.List;

/**
 *
 * @author umut
 */
public class ApartmentTypeDAO implements DAO<ApartmentType>{
    
    @Override
    public void insert(ApartmentType entity) {
    }

    @Override
    public List<ApartmentType> getList() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
