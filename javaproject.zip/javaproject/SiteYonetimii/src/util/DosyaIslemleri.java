package util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DosyaIslemleri {

    File f = new File("veri.txt");

    public void yazdir(String veri) throws IOException {

        if (!f.exists()) {
            try {
                f.createNewFile();
            } catch (IOException ex) {
                Logger.getLogger(DosyaIslemleri.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        FileWriter fw = new FileWriter(f, true);
        fw.write(veri + "\n");
        fw.close();

    }

    public void oku() throws FileNotFoundException, IOException {

        List<String> list = new ArrayList<>();

        if (!f.exists()) {
            try {
                f.createNewFile();
            } catch (IOException ex) {
                Logger.getLogger(DosyaIslemleri.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        FileReader fr = new FileReader(f);
        BufferedReader br = new BufferedReader(fr);
        String line;

        while ((line = br.readLine()) != null) {
            System.out.println(line);
        }
        br.close();

    }

}
