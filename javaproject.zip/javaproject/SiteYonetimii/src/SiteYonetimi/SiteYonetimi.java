
package SiteYonetimi;

import GUI.block.AddWindow;

//
public class SiteYonetimi {
    public static void main(String[] args) {
       AddWindow aw = new AddWindow();
       aw.build();
    }
    
}
