
package GUI.block;

import Controller.action.BlockActionListener;
import java.awt.event.ActionListener;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class AddWindow {
    private JFrame window;
    JPanel mainPanel;
    JLabel blockName;
    JTextField block;
    JButton save;

    public AddWindow() {
        
        
        
    }
    
    public void build(){
        this.getWindow().setContentPane(this.getMainPanel());
        this.getMainPanel().add(this.getBlockName());
        this.getMainPanel().add(this.getBlock());
        this.getMainPanel().add(this.getSave());
        
        this.getWindow().setVisible(true);
        
    }
    
    
    
    public JFrame getWindow() {
        if(this.window == null){
            this.window = new JFrame("Blok Ekle");
            window.setBounds(100,100,200,300);
            window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            
        }
        return window;
    }

    public void setWindow(JFrame window) {
        this.window = window;
    }

    public JPanel getMainPanel() {
        if(this.mainPanel == null){
            this.mainPanel = new JPanel();
            mainPanel.setLayout(new BoxLayout(mainPanel, 0));
            
        }
        this.mainPanel = mainPanel;
        return mainPanel;
    }

    public void setMainPanel(JPanel mainPanel) {
        
    }

    public JLabel getBlockName() {
        if(this.blockName == null){
            this.blockName = new JLabel("Blok ismi: ");
            
            
        }
        return blockName;
    }

    public void setBlockName(JLabel blockName) {
        this.blockName = blockName;
    }

    public JTextField getBlock() {
        if(this.block == null){
            this.block = new JTextField();
            
            
        }
        return block;
    }

    public void setBlock(JTextField block) {
        this.block = block;
    }

    public JButton getSave() {
        if(this.save == null){
            save = new JButton();
            this.save.addActionListener(new BlockActionListener(this));
        }
        return save;
    }

    public void setSave(JButton save) {
        this.save = save;
    }
    
    
    
}
