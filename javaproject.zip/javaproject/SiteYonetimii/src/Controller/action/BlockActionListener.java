/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller.action;

import Controller.BlockController;
import GUI.block.AddWindow;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author umut
 */
public class BlockActionListener implements ActionListener{
    
    private AddWindow aw;
    private BlockController bc;
    
    public BlockActionListener(AddWindow aw) {
        this.aw = aw;
    }
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
       if(e.getSource() == aw.getSave()){
           try {
               String blockName = aw.getBlock().getText();
               this.getBc().create(blockName);
               
               
           } catch (IOException ex) {
           }
           
       }
    }

    public BlockController getBc() {
        if(this.bc == null){
            this.bc = new BlockController();
        }
        return bc;
    }
    
}
