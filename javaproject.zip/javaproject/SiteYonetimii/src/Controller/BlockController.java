
package Controller;

import DAO.BlockDAO;
import entity.Block;
import java.io.IOException;
import java.util.List;


public class BlockController {
    private Block entity;
    private List<Block> list;
    private BlockDAO dao;
    
    
    public void create(String blockName) throws IOException{
        Block newBlock = this.getEntity();
        newBlock.setBlock(blockName);
        this.getDao().insert(newBlock);
        
        
    }

    public Block getEntity() {
        if(this.entity == null){
            entity = new Block();
        }
        return entity;
    }

    public void setEntity(Block entity) {
        this.entity = entity;
    }

    public List<Block> getList() {
        return list;
    }

    public void setList(List<Block> list) {
        this.list = list;
    }

    public BlockDAO getDao() {
        if(this.dao == null){
            dao = new BlockDAO();
        }
        return dao;
    }

    public void setDao(BlockDAO dao) {
        this.dao = dao;
    }
    
}
