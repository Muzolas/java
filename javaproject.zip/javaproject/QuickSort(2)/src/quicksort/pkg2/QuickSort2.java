/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package quicksort.pkg2;

import java.util.Random;

/**
 *
 * @author Muzaffer
 */
public class QuickSort2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int Enaz_islemSayisi = Integer.MAX_VALUE;
        int minPivotIndex = -1;

        int boyut = 100;
        int[] dizi = new int[boyut];

        Random randomSayilar = new Random();

        for (int i = 0; i < dizi.length; i++) {
            dizi[i] = randomSayilar.nextInt(100);
        }

        int[] pivotIndeksleri = {0, 9, 19, 29, 39, 49, 59, 69, 79, 89, 99};

        for (int pivotIndeks : pivotIndeksleri) {

            int pivot = dizi[pivotIndeks];
            int i = 0;
            int j = boyut - 1;

            while (i <= j) {
                while (dizi[i] < pivot) {
                    i++;
                }
                while (dizi[j] > pivot) {
                    j--;
                }
                if (i <= j) {

                    int gecici = dizi[i];
                    dizi[i] = dizi[j];
                    dizi[j] = gecici;
                    i++;
                    j--;
                }
            }

        }

        for (int pivotIndeks : pivotIndeksleri) {

            int pivot = dizi[pivotIndeks];
            int i = 0, j = boyut - 1;

            while (i <= j) {
                while (dizi[i] < pivot) {
                    i++;
                }
                while (dizi[j] > pivot) {
                    j--;
                }
                if (i <= j) {
                    int gecici = dizi[i];
                    dizi[i] = dizi[j];
                    dizi[j] = gecici;
                    i++;
                    j--;
                }
            }

            int islemSayisi = i;

            if (islemSayisi < Enaz_islemSayisi) {

                Enaz_islemSayisi = islemSayisi;
                minPivotIndex = pivotIndeks;

            }
            pivotIndeks = pivotIndeks + 1;
            System.out.println("Pivot %" + pivotIndeks + " konumunda secildiginde islem sayisi: " + islemSayisi);
        }

        minPivotIndex = minPivotIndex + 1;
        System.out.println("Pivot % " + minPivotIndex + " konumunda secildiginde islem sayisi en azdir: " + Enaz_islemSayisi);

    }
}
