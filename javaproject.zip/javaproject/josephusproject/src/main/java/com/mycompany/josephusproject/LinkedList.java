/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.josephusproject;

import java.util.Scanner;

/**
 *
 * @author Muzaffer
 */
public class LinkedList {

    Scanner sc = new Scanner(System.in);
    private Node head = null;
    private Node tail = null;

    public void Add() {

        System.out.print("How many people are on the list: ");
        int x = sc.nextInt();

        int value = 1;

        while (value <= x) {

            Node newNode = new Node(value);

            if (head == null) {
                head = newNode;
            } else {
                tail.next = newNode;
            }
            tail = newNode;
            newNode.next = head;
            value += 1;
        }

    }

    public void Delete() {

        Node temp = head;

        if (head == null) {
            System.out.println("List is empty...");
        } else {
            do {
                
                    temp.next.next = temp.next.next.next;
                    temp = temp.next.next.next;
                    System.out.println(Elements());
                

            } while (Elements() > 2);

        }
    }

    public void Print() {

        Node temp = head;

        if (head == null) {
            System.out.println("List is empty...");
        } else {
            do {
                System.out.print(" " + temp.data);
                temp = temp.next;

            } while (temp != head);

        }
    }

    public int Elements() {
        if (head == null) {
            System.out.println("List is empty...");
            return 0;
        } else {
            Node availableNode = head;
            int temp = 0;
            do {
                temp += 1;
                availableNode = availableNode.next;
            } while (availableNode != head);
            
            return temp;
        }
    }
}
