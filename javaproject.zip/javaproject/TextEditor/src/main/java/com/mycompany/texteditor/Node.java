package com.mycompany.texteditor;

/**
 *
 * @author Muzaffer
 */

public class Node {
    
    int index;
    String word;
    
    public Node(int i, String w)
    {
        index = i;
        word = w;
    }
    
    public String ToString()
    {
       return index + " - " + word;
    }
}
