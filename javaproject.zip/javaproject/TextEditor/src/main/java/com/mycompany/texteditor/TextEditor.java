package com.mycompany.texteditor;

/**
 *
 * @author Muzaffer
 */

public class TextEditor {

    public static void main(String[] args) {

        EditorGUI textEditor = new EditorGUI();
        textEditor.show();
    }
}
