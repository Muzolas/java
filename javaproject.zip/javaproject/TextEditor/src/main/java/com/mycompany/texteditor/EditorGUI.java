package com.mycompany.texteditor;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.KeyEvent;
import java.util.Stack;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.text.html.HTMLEditorKit;

/**
 *
 * @author Muzaffer
 */
public class EditorGUI extends javax.swing.JFrame {

    public EditorGUI() {
        initComponents();
    }

    int i = 0;
    int lastindex = 0;
    Stack undos = new Stack();
    Stack redos = new Stack();

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        textPane = new javax.swing.JTextPane();
        undo = new javax.swing.JButton();
        redo = new javax.swing.JButton();
        title = new javax.swing.JLabel();
        bold = new javax.swing.JButton();
        italic = new javax.swing.JButton();
        cbfont = new javax.swing.JComboBox<>();
        color = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        textPane.setFont(new java.awt.Font("Segoe UI", 0, 25)); // NOI18N
        textPane.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textPaneKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(textPane);

        undo.setText("Undo");
        undo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                undoActionPerformed(evt);
            }
        });

        redo.setText("Redo");
        redo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                redoActionPerformed(evt);
            }
        });

        title.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        title.setText("TEXT EDITOR ");

        bold.setText("Bold");
        bold.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boldActionPerformed(evt);
            }
        });

        italic.setText("Italic");
        italic.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                italicActionPerformed(evt);
            }
        });

        cbfont.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Arial", "Calibri", "Candara", "DialogInput", "Georgia", "Ink Free", "Impact", "Lucida Console", "Microsoft Himalaya", "Monospaced", "MV Boli", "MingLiu-ExtB", "Mongolian Baiti", "Segoe Print", "Segoe Script", "Segoe UI", "Segoe UI Black", "Sylfaen", "SansSerif", "Times New Roman", "Verdana", "Yu Gothic" }));
        cbfont.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbfontActionPerformed(evt);
            }
        });

        color.setText("Color");
        color.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                colorActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(color, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(title, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(undo, javax.swing.GroupLayout.DEFAULT_SIZE, 162, Short.MAX_VALUE)
                                    .addComponent(bold, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(redo, javax.swing.GroupLayout.DEFAULT_SIZE, 162, Short.MAX_VALUE)
                                    .addComponent(italic, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addComponent(cbfont, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(undo)
                            .addComponent(redo))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(bold)
                            .addComponent(italic)))
                    .addComponent(title, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbfont, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(color))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 404, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void undoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_undoActionPerformed
        Node lastElement = (Node) undos.pop();

        redos.push(lastElement);

        String writing = textPane.getText();

        String lastWriting = writing.substring(0, lastElement.index);

        textPane.setText(lastWriting);

    }//GEN-LAST:event_undoActionPerformed

    private void redoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_redoActionPerformed
        String writing = textPane.getText();
        Node sonEleman = (Node) redos.pop();

        writing = writing + " " + sonEleman.word;
        undos.push(new Node(i, writing));
        lastindex = i + 1;
        i++;
        textPane.setText(writing);

    }//GEN-LAST:event_redoActionPerformed

    private void italicActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_italicActionPerformed
        italic.setAction(new HTMLEditorKit.ItalicAction());

    }//GEN-LAST:event_italicActionPerformed

    private void boldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boldActionPerformed
        bold.setAction(new HTMLEditorKit.BoldAction());
    }//GEN-LAST:event_boldActionPerformed

    private void cbfontActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbfontActionPerformed
        JComboBox source = (JComboBox) evt.getSource();
        String item = (String) source.getSelectedItem();
        textPane.setFont(new Font(item, Font.PLAIN, 25));
    }//GEN-LAST:event_cbfontActionPerformed

    private void colorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_colorActionPerformed
        JColorChooser colorChooser = new JColorChooser();
        Color color = colorChooser.showDialog(null, "Choose a color", Color.black);
        textPane.setForeground(color);
    }//GEN-LAST:event_colorActionPerformed

    private void textPaneKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textPaneKeyPressed
        if (evt.getKeyChar() == ' ') {
            String writing = textPane.getText();
            String word = writing.substring(lastindex, writing.length() - 1);

            undos.push(new Node(i, word));
            lastindex = i + 1;
        }
        i++;
        if (evt.getKeyCode() == KeyEvent.VK_Z && evt.isControlDown()) {
            Node lastElement = (Node) undos.pop();

            redos.push(lastElement);

            String writing = textPane.getText();

            String lastWriting = writing.substring(0, lastElement.index);

            textPane.setText(lastWriting);
        }
        if (evt.getKeyCode() == KeyEvent.VK_Y && evt.isControlDown()) {
            String writter = textPane.getText();
            Node lastElement = (Node) redos.pop();

            writter = writter + " " + lastElement.word;
            undos.push(new Node(i, writter));
            lastindex = i + 1;
            i++;
            textPane.setText(writter);
        }

    }//GEN-LAST:event_textPaneKeyPressed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> {
            new EditorGUI().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bold;
    private javax.swing.JComboBox<String> cbfont;
    private javax.swing.JButton color;
    private javax.swing.JButton italic;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton redo;
    private javax.swing.JTextPane textPane;
    private javax.swing.JLabel title;
    private javax.swing.JButton undo;
    // End of variables declaration//GEN-END:variables
}
