/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.yigitdizi;

/**
 *
 * @author Muzaffer
 */
public class Yigit_Dizi {

    int[] dizi;
    int boyut, ilk;

    Yigit_Dizi(int boyut) {
        this.boyut = boyut;
        this.dizi = new int[this.boyut];
        this.ilk = -1;
    }

    public void Ekleme(int deger) {
        if (ilk == this.boyut - 1) {
            System.out.println("Yığıt Dolu...");
        } else {
            ilk++;
            dizi[ilk] = deger;
            System.out.println("Ekleme başarılı: " + deger);
        }
    }

    public int Cıkarma() {
        if (ilk == -1) {
            System.out.println("Yığıt Boş...");
            return -1;
        } else {
            ilk--;
            System.out.println("Silme başarılı: " + dizi[ilk + 1]);
            return dizi[ilk + 1];
        }
    }

    public int Arama(int aranan) {
        int x = 0;
        while (x < this.boyut) {
            if (aranan == dizi[x]) {
                System.out.println("Sayı bulundu: " + aranan);
                return aranan;
            }
            x++;
        }
        System.out.println("Sayı bulunamadı...");
        return 0;
    }

    public void Yazdirma() {
        if (ilk == -1) {
            System.out.println("Yığıt Boş...");
        } else {
            int x = 0;
            while (x <= ilk) {
                System.out.print(" " + dizi[x]);
                x++;
            }

        }

    }
}
