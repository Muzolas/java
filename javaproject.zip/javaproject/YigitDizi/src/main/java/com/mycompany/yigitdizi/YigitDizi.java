/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.yigitdizi;

import java.util.Scanner;

/**
 *
 * @author Muzaffer
 */
public class YigitDizi {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Yığıt yapısının boyutunu giriniz: ");
        int boyut = sc.nextInt();
        Yigit_Dizi y = new Yigit_Dizi(boyut);

        int islem;

        do {
            System.out.print("""
                             
                             -------------------
                             \tMenü
                             -------------------
                             1-Ekleme
                             2-Çıkarma 
                             3-Arama
                             4-Yazdırma
                             5-Çıkış
                             -------------------
                             
                             İşlemi seçiniz: """);

            islem = sc.nextInt();

            switch (islem) {

                case 1 -> {
                    System.out.print("Eklenicek sayıyı giriniz: ");
                    int sayi = sc.nextInt();
                    y.Ekleme(sayi);
                    y.Yazdirma();
                    System.out.println("");
                }

                case 2 -> {
                    y.Cıkarma();
                    y.Yazdirma();
                    System.out.println("");
                }
                case 3 -> {
                    System.out.print("Aramak istediğiniz sayıyı giriniz: ");
                    int sayi1 = sc.nextInt();
                    y.Arama(sayi1);
                }
                case 4 -> {
                    y.Yazdirma();
                }
                case 5 -> {
                }
                default ->
                    System.out.println("Geçersiz işlem...");
            }
        } while (islem != 5);
    }
}
