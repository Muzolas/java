/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.arraystackmain;

/**
 *
 * @author Muzaffer
 */
public class Arraystack {
    
    int[] array;
    int size, first;

    // Dizi boyutunu belirleme                     
    public Arraystack(int size) {
        this.size = size;
        this.array = new int[this.size];
        this.first = -1;
    }
    
    // Yığıt yapısının ekleme metodu 
    public void Push(int value) {
        if (!isFull()) {
            first++;
            array[first] = value;
            System.out.println("Add successful: " + value);

        } else {
            System.out.println("Stack is full.");
        }

    }
    
    // Yığıt yapısının silme metodu
    public int Pop() {
        if (!isEmpty()) {
            first--;
            System.out.println("Dismounted: " + array[first + 1]);
            return array[first + 1];

        } else {
            System.out.println("Stuck is empty.");
            return -1;
        }
    }
    
    // Yığıt yapısında aranan sayının indeksini dödüren metod
    public int search(int value1) {
        for (int x = 0; x < this.size; x++) {
            if (array[x] == value1) {
                System.out.println("Number is found: " + value1);
                return value1;
            }
        }
        System.out.println("Number is not found.");
        return 0;

    }
    
    // Yığıt içindeki değerleri yazdıran metod
    public void display() {
        if (!isEmpty()) {
            int x;
            for (x = 0; x <= first; x++) {
                System.out.print(" " + array[x]);
            }
        } else {
            System.out.println("Stuck is empty.");
        }

    }
    
    // Boş mu metodu
    public boolean isEmpty() {
        if (first == - 1) {
            return true;
        } else {
            return false;
        }
    }
    
    // Dolu mu metodu
    public boolean isFull() {
        if (first == this.size - 1) {
            return true;
        } else {
            return false;
        }
    }

}
