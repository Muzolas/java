/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.arraystackmain;

import java.util.Scanner;

/**
 *
 * @author Muzaffer
 */


public class Arraystackmain {
    
    /*1- Array'de ulaşmak istediğimiz elemana indisini girerek ulaşırız. 
         Linked List’lerde ise ulaşmak istediğimiz elemanlara point eden pointerlar vasıtasıyla ulaşırız.
    
      2- Linked List dinamiktir. Array tanımlaması yapılırken en başında veri boyutunu belirtmemiz gerekirken, 
         Linked List’lerde ihtiyaç duyduğumuzda boyutu artırabilir, silme işlemlerimizden sonra Linked List boyutumuzu küçültebiliriz.
    
      3- Array'lerde eleman ekleme, silme gibi işlemler Linked List’lere göre performans açısından daha maliyetlidir. 
         
      4- Linked List’ler, sadece veriyi değil veri ile birlikte bir sonraki düğüme işaret eden pointerları da tuttuğu için 
         array'lerden daha fazla hafızada yer kaplar.
    
      5- Linked List’lerde random bir veriye ulaşım dizilere göre maliyetlidir. Dizilerde dilediğimiz elemana indisini girerek ulaşabiliyorken,
         Linked List’lerde ise pointerlar aracılığı ile liste üzerinde gezinmemiz gerekir. Bu da performans kaybına yol açar.
    */
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of the stack structure: ");
        int size = sc.nextInt();
        Arraystack s = new Arraystack(size);
        int process;
        do {
            System.out.print("\n-------------------\n\tMenu\n-------------------\n1-Addition\n2-Subtraction\n3-Search\n4-Exit\n-------------------\n\nSelect the process: ");
            process = sc.nextInt();

            switch (process) {

                case 1:
                    System.out.print("Adding element: ");
                    int number = sc.nextInt();
                    s.Push(number);
                    s.display();
                    System.out.println("");
                    break;

                case 2:
                    s.Pop();
                    System.out.println("Subtraction successful.");
                    s.display();
                    System.out.println("");
                    break;
                case 3:
                    System.out.print("Enter the value you want to search for: ");
                    int number1 = sc.nextInt();
                    s.search(number1);
                    break;
                case 4:
                    break;
                default:
                    System.out.println("Incorrect operation...");
            }
        } while (process != 4);
    }
}
